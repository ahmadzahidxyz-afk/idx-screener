# IDX Stock Screener
### Technical Analysis Scanner — Yahoo Finance + Flask

---

## 🚀 Cara Menjalankan

### Windows
```
double-click run.bat
```

### Mac / Linux
```bash
chmod +x run.sh
./run.sh
```

### Manual
```bash
pip install -r requirements.txt
python screener.py
```

Kemudian buka browser: **http://localhost:5000**

---

## ✅ Fitur Screener

| Kriteria | Detail |
|---|---|
| **Stochastic 10,5,5** | K% cross D% (golden cross) **ATAU** K% > D% (tanpa cross) |
| **Volume** | Minimum volume per hari (default: 1.000.000 lembar) |
| **Value** | Minimum nilai transaksi (default: Rp 1.000.000.000) |
| **MACD > Signal** | Golden Cross (baru cross) **ATAU** MACD sudah di atas Signal |
| **Fibonacci 0.618** | Harga dalam area entry fib 0.618 ± toleransi % (Daily TF) |

---

## 📊 Indikator Teknikal

### Stochastic (10, 5, 5)
- K Period: 10 candle
- Smoothing K: 5
- D Period: 5
- **Mode Cross**: K% baru saja melintasi ke atas D% (sinyal kuat)
- **Mode Tanpa Cross**: K% sudah berada di atas D% (sudah dalam momentum)

### MACD (12, 26, 9)
- Fast EMA: 12
- Slow EMA: 26
- Signal: 9
- **Mode Golden Cross**: MACD baru saja melewati Signal ke atas
- **Mode Tanpa Cross**: MACD sudah di atas Signal

### Fibonacci Retracement
- Dihitung dari High-Low 252 hari trading terakhir (±1 tahun)
- Target: Level 0.618 (area support retracement)
- Toleransi default: ±2% dari level 0.618

---

## 📁 Struktur File

```
idx_screener/
├── screener.py          # Backend utama (Flask + yfinance)
├── requirements.txt     # Dependencies Python
├── run.bat             # Windows launcher
├── run.sh              # Mac/Linux launcher
├── README.md           # Dokumentasi ini
└── templates/
    └── index.html      # UI Web
```

---

## ⚙️ Konfigurasi

Edit `IDX_STOCKS` di `screener.py` untuk menambah/mengurangi daftar saham.

**Jumlah saham saat ini: ~250 saham** (LQ45, IDX80, dan saham populer lainnya)

---

## 📝 Catatan

- Data diambil real-time dari Yahoo Finance
- Proses scan ~250 saham membutuhkan waktu 5–15 menit (tergantung koneksi)
- Ada delay 0.3 detik per saham untuk menghindari rate limit Yahoo
- Gunakan fitur **Stop** untuk menghentikan scanning kapan saja
- Hasil bisa di-sort berdasarkan kolom manapun

---

## 🐛 Troubleshooting

**Error: yfinance not found**
```bash
pip install yfinance flask pandas numpy
```

**Port 5000 sudah digunakan**
Edit baris terakhir `screener.py`:
```python
app.run(debug=False, port=5001)  # ganti port
```

**Data tidak muncul / None**
- Beberapa saham mungkin delisted atau data tidak tersedia di Yahoo Finance
- Simbol dengan volume 0 otomatis dilewati
