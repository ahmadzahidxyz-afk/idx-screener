@echo off
echo =============================================
echo   IDX Stock Screener - Setup
echo =============================================
echo.

echo [1/2] Install dependencies...
pip install -r requirements.txt

echo.
echo [2/2] Launching Screener...
echo Buka browser: http://localhost:5000
echo.
python screener.py
pause
