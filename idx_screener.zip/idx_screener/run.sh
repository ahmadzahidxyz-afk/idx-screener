#!/bin/bash
echo "============================================="
echo "  IDX Stock Screener - Setup & Run"
echo "============================================="
echo ""

echo "[1/2] Install dependencies..."
pip install -r requirements.txt

echo ""
echo "[2/2] Launching Screener..."
echo "Buka browser: http://localhost:5000"
echo ""
python3 screener.py
