"""
IDX Stock Screener - Backend Python + Yahoo Finance
=====================================================
Menjalankan: python screener.py
Buka browser: http://localhost:5000
"""

import json
import threading
import time
from datetime import datetime, timedelta
from flask import Flask, render_template, jsonify, request

try:
    import yfinance as yf
    import pandas as pd
    import numpy as np
    YFINANCE_OK = True
except ImportError:
    YFINANCE_OK = False
    print("[ERROR] Jalankan: pip install yfinance pandas numpy flask")

app = Flask(__name__)

# ─────────────────────────────────────────────
#  DAFTAR SAHAM IDX (LQ45 + IDX80 + POPULER)
# ─────────────────────────────────────────────
IDX_STOCKS = [
    "AALI","ACES","ADHI","ADMG","ADRO","AGII","AGRO","AKRA","AMRT","ANTM",
    "APLN","ARNA","ASGR","ASII","ASRI","AUTO","BBCA","BBNI","BBRI","BBTN",
    "BCAP","BCIC","BDMN","BEEN","BEST","BFIN","BGTG","BHAT","BHIT","BIRD",
    "BJBR","BJTM","BKSL","BKST","BMAS","BMRI","BNBA","BNBR","BNII","BNGA",
    "BPFI","BPII","BPKH","BRIS","BRMS","BRPT","BSDE","BSSR","BTEL","BTON",
    "BUKA","BULL","BWPT","CASS","CEKA","CLEO","CMPP","CNKO","CPIN","CSAP",
    "CTRA","DCII","DEWA","DMAS","DSNG","DSSA","DVLA","EKAD","ELSA","EMTK",
    "ERAA","ESSA","EXCL","FILM","FITT","GGRM","GIAA","GOTO","GGRP","HAIS",
    "HEAL","HEXA","HMSP","HOKI","HRTA","ICBP","IGAR","IMAS","IMJS","INCO",
    "INDF","INDX","INDY","INKP","INPC","INPP","INTP","IPCC","ISAT","ITMG",
    "JKON","JRPT","JSPT","JTPE","KAEF","KBLI","KBLM","KLBF","KOPI","KRAS",
    "LINK","LPPF","LPPS","LSIP","MAIN","MAPA","MAPI","MCAS","MDKA","MFIN",
    "MIKA","MIRA","MITI","MKPI","MLPT","MNCN","MPPA","MRAT","MSKY","MTDL",
    "MTLA","MYOR","NCKL","NISP","OKAS","PANI","PANR","PBID","PBRX","PGAS",
    "PGEO","PKPK","PNBN","PNIN","POWR","PPRE","PRDA","PTBA","PTPP","PTRO",
    "PWON","RAJA","RALS","RANC","RATU","RDTX","RELI","RISE","ROTI","RUPB",
    "SAME","SBMA","SCMA","SIDO","SILO","SIMP","SIUP","SKBM","SKLT","SMAR",
    "SMDR","SMGR","SMIL","SMRA","SMSM","SOCI","SONA","SRTG","SSMS","STAA",
    "STTP","SUPR","TALF","TBIG","TBLA","TCPI","TELE","TFAS","TINS","TKIM",
    "TLKM","TOBA","TOWR","TPMA","TPIA","TRIM","TRIO","TRIS","TRST","TSPC",
    "ULTJ","UNIQ","UNTR","UNVR","VKTR","WEGE","WIKA","WINS","WIRG","WOOD",
    "WTON","YELO","ZINC",
]

# ─────────────────────────────────────────────
#  INDIKATOR TEKNIKAL
# ─────────────────────────────────────────────

def compute_stochastic(high, low, close, k_period=10, d_period=5, smooth_k=5):
    """Stochastic Oscillator %K dan %D"""
    lowest_low = low.rolling(window=k_period).min()
    highest_high = high.rolling(window=k_period).max()
    raw_k = 100 * (close - lowest_low) / (highest_high - lowest_low + 1e-10)
    k = raw_k.rolling(window=smooth_k).mean()
    d = k.rolling(window=d_period).mean()
    return k, d

def compute_macd(close, fast=12, slow=26, signal=9):
    """MACD Line, Signal Line, Histogram"""
    ema_fast = close.ewm(span=fast, adjust=False).mean()
    ema_slow = close.ewm(span=slow, adjust=False).mean()
    macd_line = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    histogram = macd_line - signal_line
    return macd_line, signal_line, histogram

def compute_fibonacci(high_val, low_val):
    """Fibonacci Retracement Levels"""
    diff = high_val - low_val
    levels = {
        "0.0":   high_val,
        "0.236": high_val - 0.236 * diff,
        "0.382": high_val - 0.382 * diff,
        "0.5":   high_val - 0.5   * diff,
        "0.618": high_val - 0.618 * diff,
        "0.786": high_val - 0.786 * diff,
        "1.0":   low_val,
    }
    return levels

def is_near_fibonacci(price, fib_levels, tolerance_pct=2.0):
    """Cek apakah harga berada di sekitar level 0.618 Fibonacci"""
    target = fib_levels["0.618"]
    lower = target * (1 - tolerance_pct / 100)
    upper = target * (1 + tolerance_pct / 100)
    return lower <= price <= upper, target, lower, upper

# ─────────────────────────────────────────────
#  FETCH + SCREEN SATU SAHAM
# ─────────────────────────────────────────────

def screen_stock(ticker_code, params):
    """
    Fetch data Yahoo Finance dan jalankan screening.
    Returns dict result atau None jika tidak lolos/error.
    """
    ticker = ticker_code + ".JK"
    try:
        data = yf.download(
            ticker,
            period="6mo",
            interval="1d",
            auto_adjust=True,
            progress=False,
            timeout=15,
        )
        if data is None or len(data) < 50:
            return None

        # Flatten MultiIndex columns jika ada
        if isinstance(data.columns, pd.MultiIndex):
            data.columns = data.columns.get_level_values(0)

        close  = data["Close"].dropna()
        high   = data["High"].dropna()
        low    = data["Low"].dropna()
        volume = data["Volume"].dropna()

        if len(close) < 50:
            return None

        # ── Harga & Volume terkini ──
        price_now  = float(close.iloc[-1])
        vol_now    = float(volume.iloc[-1])
        value_now  = price_now * vol_now

        # ── Filter Volume ──
        if params.get("use_volume") and vol_now < params.get("min_volume", 1_000_000):
            return None

        # ── Filter Value ──
        if params.get("use_value") and value_now < params.get("min_value", 1_000_000_000):
            return None

        # ── Stochastic 10,5,5 ──
        k, d = compute_stochastic(high, low, close, k_period=10, d_period=5, smooth_k=5)
        k_now   = float(k.iloc[-1])
        d_now   = float(d.iloc[-1])
        k_prev  = float(k.iloc[-2])
        d_prev  = float(d.iloc[-2])

        stoch_cross_bullish = (k_prev <= d_prev) and (k_now > d_now)  # golden cross
        stoch_pass = False

        if params.get("use_stoch"):
            stoch_mode = params.get("stoch_mode", "cross")  # "cross" | "no_cross"
            if stoch_mode == "cross":
                stoch_pass = stoch_cross_bullish
            elif stoch_mode == "no_cross":
                stoch_pass = k_now > d_now  # K sudah di atas D tapi tidak harus cross baru
            else:
                stoch_pass = True
            if not stoch_pass:
                return None
        else:
            stoch_pass = True

        # ── MACD ──
        macd_line, signal_line, hist = compute_macd(close)
        macd_now   = float(macd_line.iloc[-1])
        signal_now = float(signal_line.iloc[-1])
        macd_prev  = float(macd_line.iloc[-2])
        sig_prev   = float(signal_line.iloc[-2])

        macd_golden_cross = (macd_prev <= sig_prev) and (macd_now > signal_now)
        macd_above = macd_now > signal_now  # MACD sudah di atas signal

        macd_pass = False
        if params.get("use_macd"):
            macd_mode = params.get("macd_mode", "golden_cross")  # "golden_cross" | "above"
            if macd_mode == "golden_cross":
                macd_pass = macd_golden_cross
            elif macd_mode == "above":
                macd_pass = macd_above
            else:
                macd_pass = True
            if not macd_pass:
                return None
        else:
            macd_pass = True

        # ── Fibonacci Daily ──
        period_days = 252  # ~1 tahun trading
        fib_data = close.tail(period_days)
        fib_high = float(fib_data.max())
        fib_low  = float(fib_data.min())
        fib_levels = compute_fibonacci(fib_high, fib_low)

        tolerance = params.get("fib_tolerance", 2.0)
        near_fib, fib_target, fib_lower, fib_upper = is_near_fibonacci(
            price_now, fib_levels, tolerance
        )

        if params.get("use_fib") and not near_fib:
            return None

        # ── Tambahan info: perubahan harga ──
        price_prev = float(close.iloc[-2])
        change_pct = (price_now - price_prev) / price_prev * 100

        return {
            "ticker":        ticker_code,
            "price":         round(price_now, 0),
            "change_pct":    round(change_pct, 2),
            "volume":        int(vol_now),
            "value":         int(value_now),
            "stoch_k":       round(k_now, 2),
            "stoch_d":       round(d_now, 2),
            "stoch_cross":   stoch_cross_bullish,
            "macd":          round(macd_now, 4),
            "macd_signal":   round(signal_now, 4),
            "macd_histogram":round(float(hist.iloc[-1]), 4),
            "macd_cross":    macd_golden_cross,
            "fib_618":       round(fib_levels["0.618"], 0),
            "fib_382":       round(fib_levels["0.382"], 0),
            "fib_near":      near_fib,
            "fib_high":      round(fib_high, 0),
            "fib_low":       round(fib_low, 0),
            "fib_lower":     round(fib_lower, 0),
            "fib_upper":     round(fib_upper, 0),
        }

    except Exception as e:
        return None

# ─────────────────────────────────────────────
#  SCREENING ENGINE (multi-thread)
# ─────────────────────────────────────────────

screening_state = {
    "running": False,
    "progress": 0,
    "total": 0,
    "results": [],
    "current_ticker": "",
    "start_time": None,
    "done": False,
    "error": None,
}

def run_screening_thread(params, stock_list):
    global screening_state
    screening_state.update({
        "running": True,
        "progress": 0,
        "total": len(stock_list),
        "results": [],
        "done": False,
        "error": None,
        "start_time": datetime.now().isoformat(),
    })

    for i, ticker in enumerate(stock_list):
        if not screening_state["running"]:
            break
        screening_state["current_ticker"] = ticker
        screening_state["progress"] = i + 1

        result = screen_stock(ticker, params)
        if result:
            screening_state["results"].append(result)

        time.sleep(0.3)  # jaga rate limit Yahoo Finance

    screening_state["running"] = False
    screening_state["done"] = True

# ─────────────────────────────────────────────
#  FLASK ROUTES
# ─────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/start_screen", methods=["POST"])
def start_screen():
    if not YFINANCE_OK:
        return jsonify({"error": "yfinance tidak terinstall. Jalankan: pip install yfinance pandas numpy flask"}), 500

    if screening_state["running"]:
        return jsonify({"error": "Screening sedang berjalan"}), 400

    params = request.json or {}
    thread = threading.Thread(
        target=run_screening_thread,
        args=(params, IDX_STOCKS),
        daemon=True,
    )
    thread.start()
    return jsonify({"status": "started", "total": len(IDX_STOCKS)})

@app.route("/api/stop_screen", methods=["POST"])
def stop_screen():
    screening_state["running"] = False
    return jsonify({"status": "stopped"})

@app.route("/api/status")
def get_status():
    return jsonify({
        "running":         screening_state["running"],
        "progress":        screening_state["progress"],
        "total":           screening_state["total"],
        "current_ticker":  screening_state["current_ticker"],
        "results":         screening_state["results"],
        "done":            screening_state["done"],
        "error":           screening_state["error"],
    })

@app.route("/api/stocks")
def get_stocks():
    return jsonify({"stocks": IDX_STOCKS, "count": len(IDX_STOCKS)})

if __name__ == "__main__":
    print("=" * 55)
    print("  IDX STOCK SCREENER")
    print("  Buka browser: http://localhost:5000")
    print("=" * 55)
    if not YFINANCE_OK:
        print("[!] Install dulu: pip install yfinance pandas numpy flask")
    app.run(debug=False, port=5000, threaded=True)
